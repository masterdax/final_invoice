@extends('layouts.app')
@include('navigation.CssRelation')
@section('content')
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-12">
                   @if(session()->has('message'))
                        <h1 class="alert alert-success">{{session()->get('message')}}</h1>
                    @endif

                        @if(session()->has('success'))
                       <div class="alert alert-success alert-block">
                           <button type="button" class="close" data-dismiss="alert">×</button>
                           <strong>{{ session()->get('success') }}</strong>
                       </div>
                        @endif
            <div class="card">
                <div class="card-header"><center><h1>Generated Invoices</h1></center></div>

                <div class="card-body ">
                 <table>
                     <thead>
                         <tr>
                            <th>Sr.</th>
                             <th>Invoice for</th>
                             <th>Created At</th>
                             <th>Action</th>
                         </tr>
                     </thead>
                     <tbody>
                       <?php $sr=1; 
                       ?>
                        @foreach($invoice_clients as $client)
                        <tr>
                            <td>{{$sr}}</td>
                            <td >{{$client->clients->client_name}}</td>
                            <td >{{$client->created_at}}</td>
                            <td>
                                <a href="{{ route('invoice.edit',$client->id)  }}" class="btn btn-success" style="color:#fff">Edit</a>
                                <a href="{{ url('/generate-invoice/') }}/{{$client->id}}" class="btn btn-primary" style="color:#fff">Invoice</a>
                                <form onsubmit="return confirm('Are you sure you want to delete this Post ?');" class="d-inline-block" action="{{route('invoice.delete',$client->id)}}" method="post">
                                    @csrf
                                    
                                                       
                                     <button type="submit" class="btn btn-danger" >DELETE</button>
                                </form>
                            </td>
                        </tr>
                         <?php $sr++; ?>
                     @endforeach   
                     </tbody>
                 </table>
                </div>
            </div>
        </div>
      
    </div>
   
</div>
@endsection