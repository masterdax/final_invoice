         
      <nav class="background-white background-primary-hightlight" >
        <div class="line">
          <div class="s-1 l-2">
            <a href="{{route('index')}}" class="logo"><img src="img/header.png" alt="" style="width: 800px;" > </a>
            
          </div>
          
          <div class="top-nav s-12 l-10 ">
            <p class="nav-text"></p>
            <ul class="right chevron">
              <li><strong><a href="{{route('index')}}">Home</a></strong></li>
              <li><strong><a href="{{route('about')}}">About Us</a></strong></li>
              <li><strong><a href="{{route('gallery')}}">Gallery</a></strong></li>
              <li><strong><a href="{{route('contact.index')}}">Contact Us</a></strong></li>
              
            </ul>
          </div>
        </div>
      </nav>
    </header>

    