<?php echo $__env->make('navigation.CssRelation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-12">
        	       <?php if(session()->has('message')): ?>
                        <h1 class="alert alert-success"><?php echo e(session()->get('message')); ?></h1>
                    <?php endif; ?>

                    <script src="/javascripts/application.js" type="text/javascript" charset="utf-8" async defer>
                    	function printpage()
                    	{
                    		window.print();
                    	}
                    </script>
            <div class="card">

                <div class="card-header"><center><h1>All Inqueries</h1></center></div>

                <div class="card-body ">
                 <table>
                     <thead>
                         <tr>
                             <th>CLIENT ID</th>
                             <th>CLIENT NAME</th>
                             <th>DATE</th>
                             <th>VIEW</th>
                             <th>EDIT</th>
                             <th>DELETE</th>
                         </tr>
                     </thead>
                     <tbody>
                        
                               <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                            <td ><?php echo e($client->id); ?></td>
                             
                             <td ><h4><a href="<?php echo e(route('client.show',$client->id)); ?>"> <?php echo e($client->client_name); ?></a></h4></td>
                             <td><?php echo e($client->created_at); ?></td>
                             <td> <a href="<?php echo e(route('client.show',$client->id)); ?>" class="btn btn-success"> View</a></td>
                             <td> <a href="<?php echo e(route('client.edit',$client->id)); ?>" class="btn btn-info"> Edit </a></td>
                             <td>
                                <form onsubmit="return confirm('Are you sure you want to delete this Post ?');" class="d-inline-block" action="<?php echo e(route('client.destroy',$client->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                                                       
                            <button type="submit" class="btn btn-danger" >DELETE</button>
                        </form>
                             </td>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                     </tbody>
                 </table>
                </div>
            </div>
        </div>
        <button class="btn btn-primary" onclick="printpage()">Print</button>

        
    </div>
    <?php echo e($clients->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MitalEng\resources\views/Client/Clientlist.blade.php ENDPATH**/ ?>