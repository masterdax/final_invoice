<?php /* C:\xampp\htdocs\MitalEng\resources\views/Bank/BankAcList.blade.php */ ?>
<?php echo $__env->make('navigation.CssRelation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-12">
        	

                    
            <div class="card">

                <div class="card-header"><center><h1>All Inqueries</h1></center></div>

                <div class="card-body ">
                	<?php if(session()->has('message')): ?>
                        <h1 class="alert alert-success"><?php echo e(session()->get('message')); ?></h1>
                    <?php endif; ?>
                 <table>
                        <thead>
                            <th>BANK ID</th>
                            <th>BANK NAME</th>
                            <th>A/C NUMBER</th>
                            <th>DATE</th>

                        </thead>
                     
                     <tbody>
                        
                               <?php $__currentLoopData = $Accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bankDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                            <td ><?php echo e($bankDetail->id); ?></td>
                             
                             <td ><h4><a href="<?php echo e(route('bank.show',$bankDetail->id)); ?>"> <?php echo e($bankDetail->bank_name); ?></a></h4></td>
                             <td ><h4><a href="<?php echo e(route('bank.show',$bankDetail->id)); ?>"> <?php echo e($bankDetail->account_number); ?></a></h4></td>
                             <td><?php echo e($bankDetail->created_at->diffForHumans()); ?></td>
                             <td> <a href="<?php echo e(route('bank.show',$bankDetail->id)); ?>" class="btn btn-success"> View</a></td>
                             <td> <a href="<?php echo e(route('bank.edit',$bankDetail->id)); ?>" class="btn btn-info"> Edit </a></td>
                             <td>
                                <form onsubmit="return confirm('Are you sure you want to delete this Post ?');" class="d-inline-block" action="<?php echo e(route('bank.destroy',$bankDetail->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                                                       
                            <button type="submit" class="btn btn-danger" >DELETE</button>
                        </form>
                             </td>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                     </tbody>
                 </table>
                </div>
            </div>
        </div>
        

        
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>