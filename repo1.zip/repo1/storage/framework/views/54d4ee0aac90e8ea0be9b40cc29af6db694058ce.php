<?php /* C:\xampp\htdocs\MitalEng\resources\views/Product/ProductList.blade.php */ ?>
<?php echo $__env->make('navigation.CssRelation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-12">
                   <?php if(session()->has('message')): ?>
                        <h1 class="alert alert-success"><?php echo e(session()->get('message')); ?></h1>
                    <?php endif; ?>

                    <script src="/javascripts/application.js" type="text/javascript" charset="utf-8" async defer>
                        function printpage()
                        {
                            window.print();
                        }
                    </script>
            <div class="card">

                <div class="card-header"><center><h1>Product List</h1></center></div>

                <div class="card-body ">
                 <table>
                     <THEAD>
                         <TH>PRODUCT ID</TH>
                         <TH>PRODUCT NAME</TH>
                         <TH>HAS/SAC</TH>
                         <TH>EDIT</TH>
                         <TH>DELETE</TH>
                     </THEAD>
                     
                     <tbody>
                        
                               <?php $__currentLoopData = $productDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                            
                             <td ><h4><a href="#"> <?php echo e($product->id); ?></a></h4></td>
                             <td ><h4> <a href="<?php echo e(route('product.show',$product->id)); ?>"> <?php echo e($product->Product_name); ?></a>
                             </h4></td>
                             <td ><h4> <?php echo e($product->has_sac); ?></h4></td>
                             
                             <td> <a href="<?php echo e(route('product.edit',$product->id)); ?>" class="btn btn-info"> Edit </a></td>
                             <td>
                                <form onsubmit="return confirm('Are you sure you want to delete this Post ?');" class="d-inline-block" action="<?php echo e(route('product.destroy',$product->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                                                       
                            <button type="submit" class="btn btn-danger" >DELETE</button>
                        </form>
                             </td>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                     </tbody>
                 </table>
                </div>
            </div>
        </div>
        

        
    </div>
   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>