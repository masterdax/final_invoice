<?php /* C:\xampp\htdocs\MitalEng\resources\views/navigation/Social.blade.php */ ?>
<!-- Social -->
      <div class="padding text-center" style="background-color: #b3b3ff">
        <a href="/"><i class="icon-facebook_circle icon2x text-white"></i></a> 
        <a href="/"><i class="icon-twitter_circle icon2x text-white"></i></a>
        <a href="/"><i class="icon-google_plus_circle icon2x text-white"></i></a>
        <a href="/"><i class="icon-instagram_circle icon2x text-white"></i></a>                                                                        
      </div>