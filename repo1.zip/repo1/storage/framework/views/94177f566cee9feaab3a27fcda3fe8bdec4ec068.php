<?php /* C:\xampp\htdocs\MitalEng\resources\views/premium.blade.php */ ?>
<!DOCTYPE html>
<html lang="en-US">
  <head>
    <?php echo $__env->make('navigation.CssRelation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
  
  <body class="size-1140">
  	<!-- PREMIUM FEATURES BUTTON -->
  	<a target="_blank" class="hide-s" href="../template/prospera-premium-responsive-business-template/" style="position:fixed;top:120px;right:-14px;z-index:10;"><img src="img/premium-features.png" alt=""></a>
    <!-- HEADER -->
    <header role="banner">    
      <!-- Top Bar -->
      <?php echo $__env->make('navigation.Topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
      
     <!-- Top Navigation -->
    <?php echo $__env->make('navigation.NavBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    
    <!-- MAIN -->
    <main role="main">
      <!-- Content -->
      <article>
        <header class="section background-primary text-center">
            <h1 class="text-white margin-bottom-0 text-size-50 text-thin text-line-height-1">Prospera Premium Features</h1>
        </header>
        <div class="section background-white"> 
          <div class="line">
            <div class="s-12 m-12 l-10 center text-center">
              <h3 class="headline text-extra-strong text-uppercase margin-bottom-40">Looks Great on Every Device</h3>
              <img class="center" src="img/responsive2.png" alt="responsive template"/>
              <h3 class="headline text-extra-strong text-uppercase margin-top-80 margin-bottom-40">Many Variants of Page Templates</h3>
              <img class="center" src="img/templates.png" alt="templates"/>
              <h3 class="headline text-extra-strong text-uppercase margin-top-80 margin-bottom-40">Magazine Page Template</h3>
              <img class="center" src="img/magazine.png" alt="magazine"/>
              <h3 class="headline text-extra-strong text-uppercase margin-top-80 margin-bottom-40">Tons of Reusable Elements</h3>
              <img class="center" src="img/tons-of-reusable-elements.png" alt="tons of reusable elements"/>
              <h3 class="headline text-extra-strong text-uppercase margin-top-80 margin-bottom-40">Animated Scroll Loading Effects</h3>
              <img class="center" src="img/content-animation.gif" alt="animated scroll loading effects"/>
              <h3 class="headline text-extra-strong text-uppercase margin-top-80">Skill Bars Animation</h3>
              <img class="center" src="img/skill-bars.gif" alt="skill bars animation"/>
              <h3 class="headline text-extra-strong text-uppercase margin-top-80 margin-bottom-40">Animated Typing</h3>
              <img class="center" src="img/typed.gif" alt="animated typing"/>
              <h3 class="headline text-extra-strong text-uppercase margin-top-80 margin-bottom-40">Count To Animation</h3>
              <img class="center" src="img/count-to.gif" alt="count to animations"/>
              <h3 class="headline text-extra-strong text-uppercase margin-top-80 margin-bottom-40">Responsive Pricing Tables<br> with Count To Animation</h3>
              <img class="center" src="img/responsive-pricing-tables.png" alt="responsive pricing tables"/>
              <h3 class="headline text-extra-strong text-uppercase margin-top-80 margin-bottom-40">Responsive Image and Video Lightbox</h3>
              <img class="center" src="img/lightbox.png" alt="responsive image and video lightbox"/>
              <h3 class="headline text-extra-strong text-uppercase margin-top-80 margin-bottom-40">Functional Ajax Contact Form</h3>
              <img class="center" src="img/contact-form.jpg" alt="ajax contact form"/>
              <h3 class="headline text-extra-strong text-uppercase margin-top-80 margin-bottom-40">and many more...</h3>
              <img class="center" src="img/only-for-2.png" alt="only-for"/>
            </div>  
          </div> 
        </div>  
      </article>
    </main>
    
    <!--FOOTER -->
    <footer>
      <!-- Main Footer -->
      <section class="section background-dark">
        <div class="line">
          <div class="margin">
            <!-- Collumn 1 -->
            <div class="s-12 m-12 l-4 margin-m-bottom-2x">
              <h4 class="text-uppercase text-strong">Our Philosophy</h4>
              <p class="text-size-20"><em>"Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt."</em><p>
                            
              <div class="line">
                <h4 class="text-uppercase text-strong margin-top-30">About Our Company</h4>
                <div class="margin">
                  <div class="s-12 m-12 l-4 margin-m-bottom">
                    <a class="image-hover-zoom" href="/"><img src="img/blog-04.jpg" alt=""></a>
                  </div>
                  <div class="s-12 m-12 l-8 margin-m-bottom">
                    <p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat.</p>
                    <a class="text-more-info text-primary-hover" href="/">Read more</a>
                  </div>
                </div>
              </div>
            </div>
            
            <!-- Collumn 2 -->
            <div class="s-12 m-12 l-4 margin-m-bottom-2x">
              <h4 class="text-uppercase text-strong">Contact Us</h4>
              <div class="line">
                <div class="s-1 m-1 l-1 text-center">
                  <i class="icon-placepin text-primary text-size-12"></i>
                </div>
                <div class="s-11 m-11 l-11 margin-bottom-10">
                  <p><b>Adress:</b> Responsive Street 7, London, UK</p>
                </div>
              </div>
              <div class="line">
                <div class="s-1 m-1 l-1 text-center">
                  <i class="icon-mail text-primary text-size-12"></i>
                </div>
                <div class="s-11 m-11 l-11 margin-bottom-10">
                  <p><a href="/" class="text-primary-hover"><b>E-mail:</b> contact@sampledomain.com</a></p>
                </div>
              </div>
              <div class="line">
                <div class="s-1 m-1 l-1 text-center">
                  <i class="icon-smartphone text-primary text-size-12"></i>
                </div>
                <div class="s-11 m-11 l-11 margin-bottom-10">
                  <p><b>Phone:</b> 0700 000 987</p>
                </div>
              </div>
              <div class="line">
                <div class="s-1 m-1 l-1 text-center">
                  <i class="icon-twitter text-primary text-size-12"></i>
                </div>
                <div class="s-11 m-11 l-11 margin-bottom-10">
                  <p><a href="/" class="text-primary-hover"><b>Twitter</b></a></p>
                </div>
              </div>
              <div class="line">
                <div class="s-1 m-1 l-1 text-center">
                  <i class="icon-facebook text-primary text-size-12"></i>
                </div>
                <div class="s-11 m-11 l-11">
                  <p><a href="/" class="text-primary-hover"><b>Facebook</b></a></p>
                </div>
              </div>
            </div>
            
            <!-- Collumn 3 -->
            <div class="s-12 m-12 l-4">
              <h4 class="text-uppercase text-strong">Leave a Message</h4>
              <form class="customform text-white">
                <div class="line">
                  <div class="margin">
                    <div class="s-12 m-12 l-6">
                      <input name="email" class="required email border-radius" placeholder="Your e-mail" title="Your e-mail" type="text" />
                    </div>
                    <div class="s-12 m-12 l-6">
                      <input name="name" class="name border-radius" placeholder="Your name" title="Your name" type="text" />
                    </div>
                  </div>
                </div>
                <div class="s-12">
                  <textarea name="message" class="required message border-radius" placeholder="Your message" rows="3"></textarea>
                </div>
                <div class="s-12"><button class="submit-form button background-primary border-radius text-white" type="submit">Submit Button</button></div> 
              </form>
            </div>
          </div>
        </div>
      </section>
      <hr class="break margin-top-bottom-0" style="border-color: rgba(0, 38, 51, 0.80);">
      
      <!-- Bottom Footer -->
      <section class="padding background-dark">
        <div class="line">
          <div class="s-12 l-6">
            <p class="text-size-12">Copyright 2018, Vision Design - graphic zoo</p>
            <p class="text-size-12">All images have been purchased from Bigstock. Do not use the images in your website.</p>
          </div>
          <div class="s-12 l-6">
            <a class="right text-size-12" href="http://www.myresponsee.com" title="Responsee - lightweight responsive framework">Design and coding<br> by Responsee Team</a>
          </div>
        </div>
      </section>
    </footer>
    <script type="text/javascript" src="js/responsee.js"></script>
    <script type="text/javascript" src="owl-carousel/owl.carousel.js"></script>
    <script type="text/javascript" src="js/template-scripts.js"></script>
     
   </body>
</html>