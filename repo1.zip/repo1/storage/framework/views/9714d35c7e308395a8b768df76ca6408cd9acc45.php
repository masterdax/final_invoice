<?php /* C:\xampp\htdocs\MitalEng\resources\views/Navigation/LocalBootrapJs.blade.php */ ?>
<script rel="text/javascript" src="js/bootstrap.bundle.js"></script>
<script rel="text/javascript" src="js/bootstrap.bundle.min.js"></script>
<script rel="text/javascript" src="js/bootstrap.js"></script>
<script rel="text/javascript" src="js/bootstrap.min.js"></script>

