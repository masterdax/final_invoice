<?php /* C:\xampp\htdocs\MitalEng\resources\views/Login.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Bootstrap log in form</title>
	<?php echo $__env->make('navigation.CssRelation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php echo $__env->make('navigation.LocalBootstrap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<link rel="stylesheet" href="css/LoginForm.css" type="text/css">
    <script rel="text/javascript" src="js/LoginForm.js"></script>
	<link rel="stylesheet" href="css/style1.css" type="text/css">
	
</head>
<body>
	<?php echo $__env->make('navigation.NavBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!--<center style="padding-top: 25%;"><p><h1><?php echo e('Login page will be start from here.'); ?></h1></p></center>-->
		<div class="container">
			
			<div class="row">
				<div class="col-md-2"></div>
				<div class="col-md-8">
					<div class="row" style="margin-top: 120px; box-shadow: -1px 1px 50px 10px black; ">
						<div class="col-md-6">
							<ul>
								<a href="#" style="border-bottom: 2px solid #f44c89; padding: 10px; "> Log In </a>
								<a href="#">/ Sign Up</a>
							</ul>
							<lable class="lable control-label">User Name</lable>
							<input type="text" class="form-control" name="user" placeholder="User Name">
							<lable class="lable control-label">Password</lable>
							<input type="password" class="form-control" name="Password" placeholder="Password">
							<input type="checkbox"><small> Remember Me.</small>
							<a href="#"><div class="btn btn-info">Log in</div></a>
							<center><p>Foreget Password</p></center>

						</div>
						<div class="col-md-6">
							
						</div>
					</div>
				</div>
				<div class="col-md-2"></div>
			
			</div>
		</div>

</body>
</html>