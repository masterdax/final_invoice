<?php /* C:\xampp\htdocs\MitalEng\resources\views/Product/ProductShow.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><center><h1>Account Detail</h1></center></div>

                <div class="card-body ">
                    
                <h1>Product Show</h1>
                <h1><?php echo e($products -> Product_name); ?></h1>
              </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>