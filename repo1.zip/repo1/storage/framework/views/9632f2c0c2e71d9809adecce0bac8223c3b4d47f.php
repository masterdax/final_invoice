<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Mital engineering Works</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/components.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/responsee.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('owl-carousel/owl.carousel.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('owl-carousel/owl.theme.css')); ?>">
    <!-- CUSTOM STYLE -->
    <link rel="stylesheet" href="<?php echo e(asset('css/template-style.css')); ?>">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700,800&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
    <!-- <script type="text/javascript" src="<?php echo e(asset('js/jquery-1.8.3.min.js')); ?>"></script> -->
   <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <!-- <script type="text/javascript" src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script> -->
    <!-- <script type="text/javascript" src="<?php echo e(asset('js/validation.js')); ?>"></script> -->
    <!-- social Try -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" type="text/css">
    <link rel="stylesheet" type="text/css" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
       <!-- Loginform -->
    <link rel="stylesheet" href="<?php echo e(asset('css/LoginForm.css')); ?>" type="text/css">
    <script rel="text/javascript" src="<?php echo e(asset('js/LoginForm.js')); ?>"></script>

    <?php /**PATH C:\xampp\htdocs\MitalEng\resources\views/navigation/CssRelation.blade.php ENDPATH**/ ?>