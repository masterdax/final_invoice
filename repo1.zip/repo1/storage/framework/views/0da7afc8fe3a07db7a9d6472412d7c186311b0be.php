<?php /* C:\xampp\htdocs\MitalEng\resources\views/Admin/adminHome.blade.php */ ?>
		<center><h1 style="font-family: stencil; color: red;">this is admin panel</h1></center>