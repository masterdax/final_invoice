<div  class=" padding text-center" style="background-color: #b3b3ff;" >
			<a class="btn1" href="https://www.facebook.com/Mital-Engineering-Works-321184255410088/">
				<i class="fab fa-facebook-f"></i>
			</a>
			<a class="btn1" href="https://www.instagram.com/mital_engineering?r=nametag">
				<i class="fab fa-instagram"></i>
			</a>
			<a class="btn1" href="https://mitalengineeringworks.business.site/">
				<i class="fab fa-google"></i>
			</a>
			<!--<a class="btn1" href="#">
				<i class="fab fa-linkedin"></i>
			</a>
			<a class="btn1" href="#">
				<i class="fab fa-youtube"></i>
			</a>-->
		</div><?php /**PATH C:\xampp\htdocs\MitalEng\resources\views/navigation/SocialTry.blade.php ENDPATH**/ ?>