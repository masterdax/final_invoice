<?php echo $__env->make('navigation.CssRelation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-12">
                   <?php if(session()->has('message')): ?>
                        <h1 class="alert alert-success"><?php echo e(session()->get('message')); ?></h1>
                    <?php endif; ?>

                        <?php if(session()->has('success')): ?>
                       <div class="alert alert-success alert-block">
                           <button type="button" class="close" data-dismiss="alert">×</button>
                           <strong><?php echo e(session()->get('success')); ?></strong>
                       </div>
                        <?php endif; ?>
            <div class="card">
                <div class="card-header"><center><h1>Generated Invoices</h1></center></div>

                <div class="card-body ">
                 <table>
                     <thead>
                         <tr>
                            <th>Sr.</th>
                             <th>Invoice for</th>
                             <th>Created At</th>
                             <th>Action</th>
                         </tr>
                     </thead>
                     <tbody>
                       <?php $sr=1; 
                       ?>
                        <?php $__currentLoopData = $invoice_clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($sr); ?></td>
                            <td ><?php echo e($client->clients->client_name); ?></td>
                            <td ><?php echo e($client->created_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('invoice.edit',$client->id)); ?>" class="btn btn-success" style="color:#fff">Edit</a>
                                <a href="<?php echo e(url('/generate-invoice/')); ?>/<?php echo e($client->id); ?>" class="btn btn-primary" style="color:#fff">Invoice</a>
                                <form onsubmit="return confirm('Are you sure you want to delete this Post ?');" class="d-inline-block" action="<?php echo e(route('invoice.delete',$client->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    
                                                       
                                     <button type="submit" class="btn btn-danger" >DELETE</button>
                                </form>
                            </td>
                        </tr>
                         <?php $sr++; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                     </tbody>
                 </table>
                </div>
            </div>
        </div>
      
    </div>
   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MitalEng\resources\views/Invoice/index.blade.php ENDPATH**/ ?>