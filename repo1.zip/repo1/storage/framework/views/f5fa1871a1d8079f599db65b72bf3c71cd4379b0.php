<?php /* C:\xampp\htdocs\MitalEng\resources\views/client/ClientShow.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><center><h1>Client Details</h1></center></div>

                <div class="card-body ">
                    <div class="col-md-8 "> 
                        <strong>client id </strong><span class="col-md-2">: <?php echo e($clientDetails->id); ?></span>
                    </div>
                <hr>
                    <div class="col-md-8 "><strong>Client Name</strong>   <span class="col-md-2">: <?php echo e($clientDetails->client_name); ?></span> 
                    </div>
                <hr>
                    <div class="col-md-8 ">
                        <strong>Contact Person</strong>   
                        <span class="col-md-2">: <?php echo e($clientDetails->contact_person); ?></span>
                    </div>
                <hr>
                    <div class="col-md-8 ">
                        <strong>Contact number</strong>   
                        <span class="col-md-2">: <?php echo e($clientDetails->client_contact); ?></span> 
                    </div>
                <hr>
                    <div class="col-md-8 ">
                        <strong>E-mail</strong>   
                        <span class="col-md-2">: <?php echo e($clientDetails->contact_email); ?></span> 
                    </div>
                <hr>
                    <div class="col-md-8 ">
                        <strong>GST NO</strong>
                        <span class="col-md-2">: <?php echo e($clientDetails->gst_no); ?></span> 
                    </div>
                <hr>

                    <div class="col-md-8 ">
                        <strong>Client Address</strong>
                        <span class="col-md-2">: <?php echo e($clientDetails->client_address); ?></span> 
                    </div>
                <hr>
              </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>