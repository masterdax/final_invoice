<?php /* C:\xampp\htdocs\MitalEng\resources\views/Client/ClientShow.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><center><h1>Inquery</h1></center></div>

                <div class="card-body ">
                                    
                    <div class="col-md-8 "> <strong>Client Name </strong><span class="col-md-2">: <?php echo e($client->client_name); ?></span></div> 
                
                <hr>
                
                    <div class="col-md-8 "> <strong>Contact NO </strong><span class="col-md-2">: <?php echo e($client->client_contact); ?></span></div> 
                
                <hr>
                
                    <div class="col-md-8 "> <strong>E-mail </strong><span class="col-md-2">: <?php echo e($client->client_email); ?></span></div> 
                
                <hr>
                
                    <div class="col-md-8 "> <strong>GST NO </strong><span class="col-md-2">: <?php echo e($client->gst_no); ?></span></div> 
                
                <hr>

                <div class="col-md-8 "><strong>Address</strong>   <span class="col-md-2">: <?php echo e($client->client_address); ?></span> </div>
                <hr>    
              </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>