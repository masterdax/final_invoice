<?php

use Faker\Generator as Faker;

$factory->define(App\BankDetail::class, function (Faker $faker) {
    return [
        //
    ];
});
