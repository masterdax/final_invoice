-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2019 at 10:22 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mitalengineering`
--

-- --------------------------------------------------------

--
-- Table structure for table `bank_details`
--

CREATE TABLE `bank_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `bank_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `branch_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `acc_holder_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_number` bigint(20) NOT NULL,
  `ifsc_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `acc_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bank_address` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bank_details`
--

INSERT INTO `bank_details` (`id`, `bank_name`, `branch_name`, `acc_holder_name`, `account_number`, `ifsc_code`, `acc_type`, `bank_address`, `created_at`, `updated_at`) VALUES
(1, 'Bank of Baroda', 'Chaani Road', 'Mital Engineering', 61234564412121, '12345', 'Current Accoun', 'dfASfaDF', '2019-06-27 12:27:35', '2019-06-27 12:27:35');

-- --------------------------------------------------------

--
-- Table structure for table `client_details`
--

CREATE TABLE `client_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_contact` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gst_no` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `client_address` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `client_details`
--

INSERT INTO `client_details` (`id`, `client_name`, `client_contact`, `client_email`, `gst_no`, `client_address`, `created_at`, `updated_at`) VALUES
(1, 'Emmet Hagenes', '542.373.2200 x359', 'crona.grace@yahoo.com', '897-450-5293 x625', '718 Arianna Fork Suite 283\nSouth Sebastianview, NJ 38319-2593', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(3, 'Prof. Luigi Strosin DDS', '+13045406198', 'cynthia06@gmail.com', '908.320.8566 x3938', '40981 Cole Street Apt. 808\nNew Davin, IA 10451-3574', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(4, 'Scotty Barrows', '+1-494-346-1166', 'areynolds@yahoo.com', '923-943-2879 x6902', '233 Kris Brook Suite 944\nNorth Milfordbury, ID 35825', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(5, 'Antonietta Erdman', '+1.652.392.4907', 'princess89@steuber.com', '667.289.2441 x9928', '1170 Strosin Run\nSouth Orionview, RI 54598-5298', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(6, 'Prof. Dayne Gusikowski', '+1 (745) 328-5819', 'barton32@grady.com', '(463) 291-9407', '90451 Harber Expressway Suite 752\nHartmannton, MS 45682-2589', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(7, 'Mr. Ismael Hane Jr.', '537-617-6280', 'markus12@rogahn.com', '425.492.9568', '20653 Zemlak Turnpike\nDoylefort, SC 14195-7974', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(8, 'Leif Ward', '+1-981-316-0101', 'joannie63@yahoo.com', '(852) 849-5843 x061', '66644 Juanita Locks Suite 459\nNorth Ozella, OR 63564-4362', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(9, 'Lelia Kuvalis', '618.268.7990 x22589', 'jackie10@yahoo.com', '1-898-734-3058 x508', '89710 Schulist Stream\nMrazfurt, NE 73852-0270', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(10, 'Myrtis Tromp', '+1.215.794.7641', 'fmcglynn@yahoo.com', '1-564-226-1430', '53400 Olson Hill\nSchmittfort, AR 46666', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(11, 'Alfonzo Reinger', '(267) 278-2798 x913', 'damore.frida@gmail.com', '(775) 660-6251 x265', '268 Kerluke Mountain Suite 665\nZemlaktown, TX 68404-5176', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(12, 'Alejandrin Bogisich', '827-788-7051 x385', 'kspinka@goodwin.net', '862.587.8437 x528', '19827 Nicklaus Manor Suite 513\nSkilesport, IA 87615', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(13, 'Prof. Coy Corwin MD', '(785) 567-0186', 'hulda41@yahoo.com', '372-318-1574', '1682 Marie Shoal\nEast George, ID 50393', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(14, 'Kendra Lubowitz Jr.', '(687) 623-8532', 'roxanne71@haley.com', '(387) 706-8489 x238', '331 Okuneva Run\nNew Cindyfurt, NY 02137', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(15, 'Marcelino Hilpert II', '+15913659180', 'leuschke.retha@schmeler.com', '+1.906.840.6757', '30863 Dave Overpass\nEast Allan, DC 68580', '2019-06-06 06:56:54', '2019-06-06 06:56:54');

-- --------------------------------------------------------

--
-- Table structure for table `generated_invoice`
--

CREATE TABLE `generated_invoice` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED DEFAULT NULL,
  `rate` double(8,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `invoice_clients_id` bigint(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `generated_invoice`
--

INSERT INTO `generated_invoice` (`id`, `product_id`, `rate`, `quantity`, `created_at`, `updated_at`, `invoice_clients_id`) VALUES
(12, 1, 100.00, 1, '2019-08-18 03:29:13', '2019-08-18 03:29:13', 10),
(15, 2, 1000.00, 2, '2019-09-21 02:33:28', '2019-09-21 02:33:28', 11);

-- --------------------------------------------------------

--
-- Table structure for table `invoice_clients`
--

CREATE TABLE `invoice_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `inv_id` bigint(20) DEFAULT NULL,
  `invoice_clients_id` bigint(20) UNSIGNED DEFAULT NULL,
  `dated` date DEFAULT NULL,
  `challan_no` int(11) DEFAULT NULL,
  `mode_terms_of_payment` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `suppliers_ref` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_ref` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buyers_order_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `buyers_order_date` date DEFAULT NULL,
  `dispatch_document_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_note_date` date DEFAULT NULL,
  `dispatched_through` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `destination` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `terms_of_delivery` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `invoice_clients`
--

INSERT INTO `invoice_clients` (`id`, `created_at`, `updated_at`, `inv_id`, `invoice_clients_id`, `dated`, `challan_no`, `mode_terms_of_payment`, `suppliers_ref`, `other_ref`, `buyers_order_no`, `buyers_order_date`, `dispatch_document_no`, `delivery_note_date`, `dispatched_through`, `destination`, `terms_of_delivery`) VALUES
(10, '2019-08-18 03:29:13', '2019-08-18 03:29:13', 10001920, 14, '2019-06-06', 123456, 'Test`', 'Test', 'Test', '1234567890', '2019-06-06', '1234567890', '2019-06-06', 'Test', 'Test', 'Test'),
(11, '2019-09-21 02:23:27', '2019-09-21 02:33:28', 111920, 1, '2019-09-22', 123456, 'Test1', 'Test1', 'Test1', '1234567890', '2019-09-23', '1234567890', '2019-09-24', 'Test1', 'Test1', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `leave_messages`
--

CREATE TABLE `leave_messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Contact` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `companyName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `YourMessage` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `leave_messages`
--

INSERT INTO `leave_messages` (`id`, `name`, `email`, `Contact`, `companyName`, `YourMessage`, `created_at`, `updated_at`) VALUES
(1, 'Maximus Altenwerth', 'carroll.ivory@okuneva.info', '+1-956-753-5231', 'Delectus doloribus debitis soluta quibusdam ipsam nesciunt sit consequatur.', 'Amet in ex tempore accusamus. Ut eos voluptatem quos vel totam. Laudantium exercitationem est ad molestiae ut suscipit voluptatem ad. Et voluptatem quasi qui voluptatem vel.', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(2, 'Prof. Tre Dibbert II', 'bsteuber@ernser.com', '(282) 268-0146 x5911', 'Maiores sed occaecati dolorum quae.', 'Eaque ipsa voluptatibus consectetur sit aut in aut. Corrupti atque voluptas et. Aut hic alias accusamus dolorum est. Dolorem porro laborum dolores molestiae delectus odit. Rerum nam fugiat quas explicabo eum. Quia similique nisi quia et inventore veritatis nesciunt.', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(3, 'Lauryn Macejkovic V', 'eernser@farrell.com', '(207) 232-1028', 'Iusto accusantium accusamus tenetur esse quas.', 'Laboriosam est consequatur molestiae sit soluta eius. Aperiam laborum sed voluptatem consequatur. Natus repudiandae repellendus eum consequatur cupiditate. Nostrum nihil voluptatem ipsa doloribus id debitis. Ducimus aliquam ut sint deserunt non ipsum amet quam. Modi voluptatem qui voluptas error rem. Totam aspernatur provident voluptas similique.', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(4, 'Dr. Kurt Schaden MD', 'larson.kiera@hotmail.com', '1-950-877-3325 x16425', 'Repudiandae vel ut vitae ea expedita corporis veritatis.', 'Eos quibusdam sed rem dolores. Et velit dignissimos aspernatur culpa quis repudiandae vitae. Sit voluptate corrupti laborum sequi necessitatibus. Sit doloremque alias iure et sunt. Accusantium totam expedita quia aut deleniti nesciunt nobis.', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(5, 'Leda Predovic', 'knikolaus@hotmail.com', '1-881-217-3460', 'Accusamus quis deserunt eligendi adipisci.', 'Aperiam aut et quisquam. Officia officiis aliquam neque reiciendis ad dolorum. Quia sunt qui ea similique a. Cumque voluptates et quia sapiente et praesentium aliquid aliquid. Aut ut quos quidem molestias quis sed. Beatae quia animi sed ut voluptatem. Dicta maiores dolores fuga impedit minima in. Unde possimus est quia in quia expedita sunt.', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(6, 'Duane Gutkowski', 'sjohns@kshlerin.com', '1-434-361-2132', 'Tenetur repudiandae aut veniam adipisci.', 'Distinctio soluta soluta quo. Eos quas aperiam consequatur aperiam et quos aliquam. Molestiae blanditiis vero corrupti veritatis aliquam id sunt. Aut assumenda ut voluptas reprehenderit nesciunt cumque eveniet. Suscipit laborum at et et eum reprehenderit. Dolor iste sed tenetur ipsa.', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(7, 'Prof. Newell Klein', 'wstehr@gmail.com', '(550) 878-1068 x1874', 'Deserunt vitae in quaerat repudiandae et vel.', 'Praesentium et delectus ducimus eius dolor qui. Et eveniet aspernatur sed. Porro similique voluptate occaecati eveniet. Omnis ad nam ut est reprehenderit accusantium placeat. At et perspiciatis reiciendis impedit quia blanditiis nostrum deleniti. Aspernatur totam rerum ut sint velit ut repudiandae. Omnis ratione amet eaque aut nulla.', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(8, 'Ms. Janie Barton DVM', 'goodwin.wilhelmine@koelpin.com', '1-730-212-9172 x690', 'Nihil porro sapiente deleniti sint voluptas sunt ut.', 'Nam sed iure a quam cum. Impedit maxime aut itaque modi rem ea occaecati fuga. Aliquam ut est corrupti quam. Asperiores exercitationem quibusdam necessitatibus veniam. Officiis non beatae numquam rem nam minima sequi. Rem quos iusto nisi porro optio voluptatem velit. Doloribus sit eos sint doloribus delectus laudantium.', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(9, 'Elinore Fadel', 'anika15@goodwin.net', '+1 (928) 337-6971', 'Cum quis aut ut quo quam.', 'Dignissimos quo ut dolorum maiores cumque esse tenetur. Dolorum dolorem aliquam ut neque soluta veritatis illum. Vel enim officia vel. Quae ipsam enim aliquid voluptatem enim adipisci et id. A deleniti sunt saepe. Optio et dolores soluta blanditiis omnis qui omnis.', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(10, 'Terrance Weimann', 'ratke.conor@hotmail.com', '763.888.3531 x9798', 'Quasi sapiente neque et quia.', 'Nihil officia ducimus delectus consectetur maxime fuga reprehenderit assumenda. Blanditiis cumque illo perferendis vel esse. Rerum molestiae iusto aut nostrum nobis. Laboriosam a non aut ut. Odio quisquam enim incidunt sunt. Repellendus voluptatem alias similique. Doloremque sit quidem perspiciatis mollitia asperiores eum ipsa.', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(11, 'Ms. Eldora Treutel PhD', 'baumbach.hilbert@hotmail.com', '1-919-770-9125', 'Odit occaecati nesciunt et non temporibus aperiam dolorum enim.', 'Ut voluptatibus repellendus cum. Quam ipsum quos architecto officia dolorem. Fuga molestiae nesciunt ducimus quia. Illum et numquam voluptatem voluptas laudantium debitis repellat. Soluta eveniet in ab sit occaecati distinctio.', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(12, 'Keon Flatley', 'eichmann.krystel@hotmail.com', '436-569-3049 x60215', 'Iste aut dicta rerum autem corporis totam sed.', 'Velit tempora nemo alias commodi. Sunt cumque ipsum nisi culpa nam et. Perspiciatis fuga tempora consequuntur ratione a id ea voluptas. Libero ratione fugiat velit voluptate id quod. Possimus voluptatem ullam itaque. Ipsam non maxime perspiciatis ad soluta. Ut sed dolore repellat quo ipsum non.', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(13, 'Aaron Jenkins', 'piper89@hotmail.com', '860-496-7211', 'Nisi nihil sit sed iure.', 'Molestiae qui et nihil pariatur et omnis repudiandae. Odio id dolorem placeat sit quidem non pariatur. Perferendis fugit voluptatibus voluptas a omnis porro. Repellat sapiente soluta exercitationem occaecati ipsam aut omnis ab. Laudantium consequatur quis necessitatibus nulla ad ut placeat. Itaque aliquam vitae ut. Nulla ea doloremque voluptas quisquam dolorum enim. Laudantium tempora ab sequi ut nulla. Quod esse exercitationem quidem.', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(14, 'Barry Skiles', 'bheidenreich@yahoo.com', '1-436-807-7849', 'Perspiciatis nisi nisi deleniti minus aperiam nihil.', 'Cupiditate expedita qui possimus ut aut corrupti. Magni beatae porro omnis eligendi. Consequuntur facere quo velit omnis fugit. Vitae nisi optio laudantium asperiores dolorem dolores possimus autem. Earum nesciunt placeat qui nulla ut non. Aut et placeat fugit aut.', '2019-06-06 06:56:54', '2019-06-06 06:56:54'),
(15, 'Danika Hirthe V', 'joshua.osinski@kozey.net', '696-472-3659', 'Et et temporibus non culpa.', 'Explicabo adipisci consequuntur aperiam et incidunt consequatur aut. Incidunt quibusdam et hic voluptas tempora qui. Ab quia quo dicta expedita illum nisi qui. Voluptatum quia et sint possimus ut. Maiores quibusdam modi est quos est laudantium. Iure non dolorem ea harum. Et aliquam voluptatem officiis corporis autem et quo pariatur. Illo animi et eum sunt tempora. Deleniti ducimus autem eum quos harum.', '2019-06-06 06:56:54', '2019-06-06 06:56:54');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_04_08_070516_create_leave_messages_table', 1),
(4, '2019_04_10_112959_create_client_details_table', 1),
(5, '2019_04_10_195726_create_bank_details_table', 1),
(6, '2019_04_20_031713_create_products_table', 1),
(7, '2019_06_12_175144_create_generated_invoice_table', 2),
(8, '2019_06_15_085911_create_invoice_clients_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('super@admin.com', '$2y$10$/wHSdVfMRLqAPewrsGFDGen/FV4KJlF.ALKtr/gR7XP3FfcXtKTEm', '2019-06-06 07:05:02');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `Product_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `has_sac` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `Product_name`, `has_sac`, `created_at`, `updated_at`) VALUES
(1, 'Machine Handle', 'MH01', '2019-06-06 07:29:06', '2019-06-06 07:29:06'),
(2, 'Test Product 2', 'TP2', '2019-06-10 21:46:13', '2019-06-10 21:46:13');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 'super@admin.com', NULL, '$2y$10$XcXk43ZLEtzA0AqiRbv2numJO4fUzjCO8wpmDZ5kstlLdBiyueX.S', NULL, '2019-06-06 07:07:14', '2019-06-06 07:07:14');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bank_details`
--
ALTER TABLE `bank_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `bank_details_account_number_unique` (`account_number`);

--
-- Indexes for table `client_details`
--
ALTER TABLE `client_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `client_details_client_name_unique` (`client_name`);

--
-- Indexes for table `generated_invoice`
--
ALTER TABLE `generated_invoice`
  ADD PRIMARY KEY (`id`),
  ADD KEY `generated_invoice_product_id_foreign` (`product_id`),
  ADD KEY `generated_invoice_invoice_clients_id_foreign` (`invoice_clients_id`);

--
-- Indexes for table `invoice_clients`
--
ALTER TABLE `invoice_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `leave_messages`
--
ALTER TABLE `leave_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_product_name_unique` (`Product_name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bank_details`
--
ALTER TABLE `bank_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `client_details`
--
ALTER TABLE `client_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `generated_invoice`
--
ALTER TABLE `generated_invoice`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `invoice_clients`
--
ALTER TABLE `invoice_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `leave_messages`
--
ALTER TABLE `leave_messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `generated_invoice`
--
ALTER TABLE `generated_invoice`
  ADD CONSTRAINT `generated_invoice_invoice_clients_id_foreign` FOREIGN KEY (`invoice_clients_id`) REFERENCES `invoice_clients` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `generated_invoice_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
